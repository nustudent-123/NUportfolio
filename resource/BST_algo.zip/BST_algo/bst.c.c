#include <stdio.h>
#include <stdlib.h>

typedef struct Node {
    int node_value;
    struct Node *left;
    struct Node *right;
} nd;

nd* create_node(int value) {
    nd* new_node = (nd*)malloc(sizeof(nd));
    new_node->node_value = value;
    new_node->left = NULL;
    new_node->right = NULL;
    return new_node;
}

nd* node_insert(nd* root, int value) {
    if (root == NULL) {
        return create_node(value);
    }

    if (value < root->node_value)
        root->left = node_insert(root->left, value);
    else if (value > root->node_value)
        root->right = node_insert(root->right, value);

    return root;
}

void inorder(nd* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->node_value);
        inorder(root->right);
    }
}

int find_size(nd* root) {
    int tot_of_nodes;
    if (root == NULL)
        return 0;
    tot_of_nodes = find_size(root->left) + find_size(root->right)+1;
    return tot_of_nodes;
}

int find_height(nd* root) {
    if (root == NULL)
        return -1; 

    int left_height = find_height(root->left);
    int right_height = find_height(root->right);

    /*if(left_height > right_height){
        return left_height;
    }
    else{
        return right_height;
    }*/
    return (left_height > right_height ? left_height : right_height) + 1;
    
}

nd* find_min(nd* root) {
    if (root == NULL)
        return NULL;

    while (root->left != NULL)
        root = root->left;

    return root;
}

nd* find_max(nd* root) {
    if (root == NULL)
        return NULL;

    while (root->right != NULL)
        root = root->right;

    return root;
}

// function to create mirror image
void mirror_image(nd* root) {
    if (root == NULL)
        return;

    nd* img = root->left;
    root->left = root->right;
    root->right = img;

    mirror_image(root->left);
    mirror_image(root->right);
}
//---------------------------------------------------------------------
int main() {
    nd* root = NULL;
    FILE *fp;
    int value;

    //get inputs by using a text file.
    fp = fopen("bst.txt", "r");
    if (fp == NULL) {
        printf("Cannot open file.\n");
        return 1;
    }

    while (fscanf(fp, "%d", &value) == 1) {
        root = node_insert(root, value);
    }
    fclose(fp);

    printf("Inorder Traversal: ");
    inorder(root);
    printf("\n");

    int height = find_height(root);
    printf("Height of BST = %d\n", height);

    int size = find_size(root);
    printf("Size of BST = %d\n", size);

    nd* min_node = find_min(root);
    if (min_node != NULL) {
        printf("Minimum Value = %d\n", min_node->node_value);
    }

    nd* max_node = find_max(root);
    if (max_node != NULL) {
        printf("Maximum Value = %d\n", max_node->node_value);
    }

    printf("Mirror Image : ");
    mirror_image(root);
    inorder(root);
    printf("\n");

    return 0;
}
