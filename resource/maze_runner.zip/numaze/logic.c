#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "type.h"

// Define blocks
block b[750];

// Define stairs, Poles, walls, flag and bawana
stair s[50];
int number_of_stair = 0; 
pole p[50];
int number_of_poles = 0;
wall w[50];
int number_of_walls = 0;
win f;

bawana bawan[12]; //to define 12 blocks in bawana

/*void bawana_function(block *b, player *p);*/
void movePlayer(player *ply, block *b,bawana *bawan, int move, win *f, stair *s, int number_of_stair );
void handleStair(player *ply, stair *s,block *b, int number_of_stair);
void bawana_function(block*b,player *ply);


// Initialize the maze blocks
void IntMaze(void) { 
    int n = 0;
    for (int i = 0; i < 3; i++) {  //floor
        for (int j = 0; j < 10; j++) {   //width
            for (int k = 0; k < 25; k++) {   //lenth
                b[n].floor = i;
                b[n].width_num = j;
                b[n].lenth_num = k;

                if ((b[n].floor == 0) && (b[n].width_num > 5) && (b[n].lenth_num > 7) && (b[n].lenth_num < 17)) {
                    b[n].state = 'd';    //deactive
                }
                else if ((b[n].floor == 1) && (b[n].width_num < 6) && (b[n].lenth_num > 7) && (b[n].lenth_num < 17)) {
                    b[n].state = 'd';   //deactive
                }
                else if ((b[n].floor == 2) && ((b[n].lenth_num < 8) || (b[n].lenth_num > 16))) {
                    b[n].state = 'd';  //deactive
                }
                else {
                    b[n].state = 'a';   //active
                }
                n++;
            }
        }
    }


    // Initialize consumable and bonus values
    int total_cells = 750;
    int consumable_zero = total_cells * 0.25;    // 25%
    int consumable_range = total_cells * 0.35;   // 35%
    int bonus_small = total_cells * 0.25;        // 25%
    int bonus_large = total_cells * 0.10;        // 10%
    int bonus_multiplier = total_cells * 0.05;   // 5%

    // Assign values to all cells
    for (int i = 0; i < total_cells; i++) {
        if (i < consumable_zero) {
            b[i].consumable = 0;
            b[i].bonus_type = 0;
        } else if (i < consumable_zero + consumable_range) {
            b[i].consumable = (rand() % 4) + 1; // 1-4
            b[i].bonus_type = 0;
        } else if (i < consumable_zero + consumable_range + bonus_small) {
            b[i].consumable = 0;
            b[i].bonus_type = 1;
            b[i].bonus_value = (rand() % 2) + 1; // 1 or 2
        } else if (i < consumable_zero + consumable_range + bonus_small + bonus_large) {
            b[i].consumable = 0;
            b[i].bonus_type = 1;
            b[i].bonus_value = (rand() % 3) + 3; // 3-5
        } else {
            b[i].consumable = 0;
            b[i].bonus_type = 2;
            b[i].bonus_value = (rand() % 2) + 2; // 2 or 3
        }
    }
}

// Seed function for random numbers
int seed(void) {
    int seed_value;
    FILE *sd = fopen("seeds.txt", "r");
    if (sd == NULL) {
        printf("Error: Failed to open seeds.txt for reading. Using current time as seed.\n");
        return (int)time(NULL);
    } else {
        if (fscanf(sd, "%d", &seed_value) != 1) { // file can have only one seed value.
            printf("Error: No valid seed value found in seeds.txt. Using current time as seed.\n");
            fclose(sd);
            return (int)time(NULL);
        } else {
            fclose(sd);
            return seed_value;
        }
    }
}

//Check the stair direction upward or downward.
void handleStair(player *ply, stair *s,block *b, int number_of_stair) {
    for(int x = 0; x < number_of_stair; x++) {
        if(s[x].direction == 0) { 
            if(ply->current.floor == s[x].start.floor &&
               ply->current.width_num == s[x].start.width_num &&
               ply->current.lenth_num == s[x].start.lenth_num) {
                printf("and can go upward.\n");
                printf("goto [%d, %d, %d] -> ",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
                ply->current = s[x].end;
                printf("[%d, %d, %d]\n",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
                x = number_of_stair;
                return;
            }
            
            
        } else { 
            if(ply->current.floor == s[x].end.floor &&
               ply->current.width_num == s[x].end.width_num &&
               ply->current.lenth_num == s[x].end.lenth_num) {
                printf("and can go downward.\n");
                printf("goto [%d, %d, %d] -> ",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
                ply->current = s[x].start;
                printf("[%d, %d, %d]\n",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
                x = number_of_stair;
                
                if ((ply->current.floor = 0 ) && (ply->current.width_num > 6) && (ply->current.lenth_num > 20)){
                    bawana_function(b,ply);
                }
                return;
            }
            
        }
    }
    
   printf("stair direction not allowed to move\n.");
   
}

// Manage players with directions and move them
void movePlayer(player *ply, block *b,bawana *bawan, int move, win *f, stair *s, int number_of_stair){ 
    printf("Player %c rolls and %d on the movement dice and moves %c by %d cells and is now at Floor:%d, Width:%d, Lenth:%d.\n",
                        ply->name,move,ply->direction,move,ply->current.floor,ply->current.width_num,ply->current.lenth_num);
    
    ply->previous = ply->current;
    
    for (int step = 0; step<move; step++){
        switch(ply->direction){
            case 'N': ply->current.width_num--; break;
            case 'W': ply->current.lenth_num--; break;
            case 'S': ply->current.width_num++; break;
            case 'E': ply->current.lenth_num++; break;
        }

        // Check the boundry of the Maze board
        if (ply->current.floor < 0 || ply->current.floor > 2 || 
            ply->current.width_num < 0 || ply->current.width_num > 9 || 
            ply->current.lenth_num < 0 || ply->current.lenth_num > 24) {
            ply->current = ply->previous;
            step = move;
            printf("Player %c landed on boundry, so can't move\n",ply->name);
            break;
        }

        // Check each blocks to manage move of players with walls, poles, stairs, deactivate blocks and flag.
        for(int j = 0; j < 750; j++){
            s->s_value = 0;
            bawan->bawana_value = 0;
            
            if (b[j].floor == ply->current.floor &&
                b[j].width_num == ply->current.width_num &&
                b[j].lenth_num == ply->current.lenth_num) {
                
            
                ply->movepoint = ply->movepoint - b[j].consumable; // Apply consumable value
                printf("dedicate consumble value by %d.\n",b[j].consumable);
                if (ply->movepoint < 0) ply->movepoint = 0;

                // Apply bonus 
                if (b[j].bonus_type == 1) {
                    ply->movepoint = ply->movepoint + b[j].bonus_value;
                    printf("Add bonus value %d\n",b[j].bonus_value);
                } else if (b[j].bonus_type == 2) {
                    ply->movepoint = ply->movepoint *b[j].bonus_value;
                    printf("Movement point multiplied by %d.\n",b[j].bonus_value);
                }

        
                if (ply->movepoint > 250) ply->movepoint = 250; // limit move point to 250

        
    
  

                switch(b[j].state){
                    case 'f':  //flag
                        printf("player %c captured the flag.\n",ply->name);
                        step = move;
                        f->win_value = 1;
                        break;
                    case 'd':  //deactivated 
                        printf("Player %c lands on diactivate block, So can't move.\n",ply->name); 
                        printf("Deactivated Block = [%d, %d, %d]\n",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
                        ply->current = ply->previous; 
                        step = move;
                        j =750;
                        break;
                    case 'w':   //wall
                        printf("Player %c lands on wall type block, So can't move.\n",ply->name);
                        printf("Wall type Block = [%d, %d, %d]\n",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
                        ply->current = ply->previous;
                        ply->movepoint = ply->movepoint - 2; 
                        step = move;
                        j = 750; 
                        break;
                    case 'p':  //pole
                        printf("Player %c lands on pole type block, So player fall down to Floor 0\n",ply->name);
                        printf("goto [%d, %d, %d] -> [0, %d, %d]\n",ply->current.floor,ply->current.width_num,ply->current.lenth_num,ply->current.width_num,ply->current.lenth_num);
                        ply->current.floor = 0; 
                        ply->current.width_num = ply->current.width_num; 
                        ply->current.lenth_num = ply->current.lenth_num; 
                        
                        if (ply->current.width_num>6 && ply->current.lenth_num>20){
                            bawana_function(b,ply);
                            ply->previous = ply->current;
                            bawan->bawana_value = 1;

                        }
                        else if((ply->current.floor = 0) && 
                                (ply->current.width_num == ply->start.width_num) && 
                                (ply->current.lenth_num == ply->start.lenth_num)){
                                ply->current = ply->start;
                                printf("Player %c fall down to the starting area by pole.\n",ply->name);
                            
                        }
                        break;
                    
                    case 's':
                        printf("Player %c lands on stair type block\n",ply->name);
                        handleStair(ply,s,b,number_of_stair);
                        ply->previous = ply->current;
                        bawan->bawana_value = 1;
                        if ((ply->current.floor = 0) && 
                            (ply->current.width_num == ply->start.width_num) && 
                            (ply->current.lenth_num == ply->start.lenth_num)){
                                ply->current = ply->start;
                                printf("Player %c move to starting area by stair.\n",ply->name);
                            }
                        break;
                }
            }
            if (f->win_value) break;
            else if(bawan->bawana_value) break;
        }
        
    }
    if (f->win_value == 1){ //when any player captured flag break the loop
        printf("//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////\n");
        printf("So player %c is the winner of the game.\n",ply->name);
        printf("Flag position = Floor:%d, Width:%d, Lenth:%d\n",ply->current.floor,ply->current.width_num,ply->current.lenth_num);
        printf("//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////\n");
    }
    else{
    
    printf("Player %c new position = Floor:%d, Width:%d, Lenth:%d\n",ply->name,ply->current.floor,ply->current.width_num,ply->current.lenth_num);                    
    printf("New movement points: %d\nCurrent direction: %c\n",ply->movepoint,ply->direction);
    }
}

void bawana_function(block *b, player *ply){
    //laod positions for bawana blocks
    printf("*****************************************\n");
    printf("Player %c entered to Bawana\n",ply->name);
    printf("*****************************************\n");
    printf("movepoints  = %d\n",ply->movepoint);
    bawan[0].name = 'F';  //Food poisoning
    bawan[0].bwan.floor = 0;
    bawan[0].bwan.width_num = 7;
    bawan[0].bwan.lenth_num = 21;

    bawan[1].name = 'F';  //Food poisoning
    bawan[1].bwan.floor = 0;
    bawan[1].bwan.width_num = 7;
    bawan[1].bwan.lenth_num = 22;

    bawan[2].name = 'D';  //Disoriented
    bawan[2].bwan.floor = 0;
    bawan[2].bwan.width_num = 7;
    bawan[2].bwan.lenth_num = 23;

    bawan[3].name = 'D'; //Disoriented
    bawan[3].bwan.floor = 0;
    bawan[3].bwan.width_num = 7;
    bawan[3].bwan.lenth_num = 24;

    bawan[4].name = 'T';  //Triggered
    bawan[4].bwan.floor = 0;
    bawan[4].bwan.width_num = 8;
    bawan[4].bwan.lenth_num = 21;

    bawan[5].name = 'T';  //Triggered
    bawan[5].bwan.floor = 0;
    bawan[5].bwan.width_num = 8;
    bawan[5].bwan.lenth_num = 22;

    bawan[6].name = 'H';  //Happy
    bawan[6].bwan.floor = 0;
    bawan[6].bwan.width_num = 8;
    bawan[6].bwan.lenth_num = 23;

    bawan[7].name = 'H';  //Happy
    bawan[7].bwan.floor = 0;
    bawan[7].bwan.width_num = 8;
    bawan[7].bwan.lenth_num = 24;

    bawan[8].name = 'O';  //Others
    bawan[8].bwan.floor = 0;
    bawan[8].bwan.width_num = 9;
    bawan[8].bwan.lenth_num = 21;

    bawan[9].name = 'O';  //Others
    bawan[9].bwan.floor = 0;
    bawan[9].bwan.width_num = 9;
    bawan[9].bwan.lenth_num = 22;

    bawan[10].name = 'O';  //Others
    bawan[10].bwan.floor = 0;
    bawan[10].bwan.width_num = 9;
    bawan[10].bwan.lenth_num = 23;

    bawan[11].name = 'O';  //Others
    bawan[11].bwan.floor = 0;
    bawan[11].bwan.width_num = 9;
    bawan[11].bwan.lenth_num = 24;

    for (int bwn_num  = 0; bwn_num<12 ; bwn_num++){
        if (ply->current.floor == 0 && ply->current.width_num == bawan[bwn_num].bwan.width_num && ply->current.lenth_num ==  bawan[bwn_num].bwan.lenth_num){
            switch (bawan[bwn_num].name){
                case 'F' :       // Food poisoning
                    ply->movepoint = 0;
                    printf("Player %c eats from Bawana and have a bad case of food poisoning. Will need three rounds to recover. \n",ply->name);
                    
                    // Set food poison rounds for manage 3 round in food poisoning loop.
                    if (ply->food_poison_rounds == 0) {
                        ply->food_poison_rounds = 3;
                    }
                    
                    // Keep player in the Food poisoning block. 
                    ply->current.floor = 0;
                    ply->current.width_num = bawan[bwn_num].bwan.width_num;
                    ply->current.lenth_num = bawan[bwn_num].bwan.lenth_num;
                    bwn_num = 12;
                    break;

                case 'D' :        // Disoriented
                    ply->movepoint = ply->movepoint + 50;
                    printf("Player %c eats from Bawana and is disoriented and is placed at the entrance of Bawana with 50 movement points.\n",ply->name);
                    ply->current.floor = 0;
                    ply->current.width_num = 9;
                    ply->current.lenth_num = 19;
                    ply->direction = 'N';
                    ply->die_index = 4;
                    break;

                case 'T' :       // Triggered
                    ply->movepoint = ply->movepoint + 50;
                    printf("Player %c eats from Bawana and is triggered due to bad quality of food. Player %c is placed at the entrance of Bawana with 50 movement points.\n",ply->name,ply->name);
                    ply->current.floor = 0;
                    ply->current.width_num = 9;
                    ply->current.lenth_num = 19;
                    ply->direction = 'N';
                    ply->die_index = 5;
                    break;

                case 'O' :      //Other  
                    ply->movepoint = ply->movepoint + ((rand()%91)+10);
                    ply->current = bawan[rand()%12].bwan;
                    printf("Player %c eats from Bawana and earns %d movement points and is placed at the [0, %d, %d]. \n",ply->name,ply->movepoint,ply->current.width_num,ply->current.lenth_num);
                    break; 
                
                case 'H' :     // Happy
                    ply->movepoint = ply->movepoint + 200;
                    printf("Player %c eats from Bawana and is happy. Player %c is placed at the entrance of Bawana with 200 movement points. \n",ply->name,ply->name);
                    ply->current.floor = 0;
                    ply->current.width_num = 9;
                    ply->current.lenth_num = 19;
                    ply->direction = 'N';
                    break;            
            }
        }
    }
}





// Load files and input data to the structs
void ConfigFiles_and_RunPlayer(void) { 
    
    f.win_value = 0;  //To break loops when any player captured the flag.
    
    // Load stairs-------------------------------------------------------------------------------------------------
    FILE *str = fopen("stairs.txt", "r");
    if (str == NULL) {
        printf("Error: Fail to open stairs.txt for reading.\n");
    } else {
        number_of_stair = 0;
        while (fscanf(str, "[%d,%d,%d,%d,%d,%d]\n", &s[number_of_stair].start.floor, &s[number_of_stair].start.width_num, &s[number_of_stair].start.lenth_num, &s[number_of_stair].end.floor, &s[number_of_stair].end.width_num, &s[number_of_stair].end.lenth_num) == 6) {
            s[number_of_stair].direction = 0; // Initialize direction
            number_of_stair++;
        }
        fclose(str);
    }

    // Load poles---------------------------------------------------------------------------------------------------
    FILE *ple = fopen("poles.txt", "r");
    if (ple == NULL) {
        printf("Error: Fail to open poles.txt for reading.\n");
    } else {
        number_of_poles = 0;
        while(fscanf(ple, "[%d,%d,%d,%d]\n", &p[number_of_poles].start.floor, &p[number_of_poles].end.floor, &p[number_of_poles].start.width_num, &p[number_of_poles].start.lenth_num) == 4) {
            number_of_poles++;
        }
        fclose(ple);
    }

    // Load walls-----------------------------------------------------------------------------------------------------
    FILE *wll = fopen("walls.txt", "r");
    if (wll == NULL) {
        printf("Error: Fail to open walls.txt for reading.\n");
    } else {
        number_of_walls = 0;
        while(fscanf(wll, "[%d,%d,%d,%d,%d]\n", &w[number_of_walls].start.floor, &w[number_of_walls].start.width_num, &w[number_of_walls].start.lenth_num, &w[number_of_walls].end.width_num, &w[number_of_walls].end.lenth_num) == 5) {
            number_of_walls++;
        }
        fclose(wll);
    }

    // Load flag-------------------------------------------------------------------------------------------------------
    FILE *flag = fopen("flag.txt", "r");
    if (flag == NULL) {
        printf("Error: Fail to open flag.txt for reading.\n");
    } else {
        while (fscanf(flag, "[%d,%d,%d]\n", &f.flag.floor, &f.flag.width_num, &f.flag.lenth_num) == 3) { }
        fclose(flag);
    }


    // Update block states
    for (int r = 0; r < 750; r++) {

        //set stair type blocks-------------------------------------------------------------------------------------------
        for (int x = 0; x < number_of_stair; x++) {
            if ((b[r].floor == s[x].start.floor || b[r].floor == s[x].end.floor) &&
                (b[r].width_num == s[x].start.width_num || b[r].width_num == s[x].end.width_num) &&
                (b[r].lenth_num == s[x].start.lenth_num || b[r].lenth_num == s[x].end.lenth_num)) {
                b[r].state = 's';
            }
        }

        //set pole type blocks---------------------------------------------------------------------------------------------
        for (int y = 0; y < number_of_poles; y++) {
            if ((b[r].floor != 0) &&
                (b[r].floor == p[y].start.floor) &&
                (b[r].width_num == p[y].start.width_num) &&
                (b[r].lenth_num == p[y].start.lenth_num)) {
                b[r].state = 'p';
                if (p[y].start.floor == 3){
                    b[250 + (p[y].start.width_num * 25) + p[y].start.lenth_num].state = 'p';
                }
            }
        }

        // set wall type blocks including wall around bawana----------------------------------------------------------------
        for (int z = 0; z < number_of_walls; z++) {
            if (((b[r].floor == w[z].start.floor) &&
                (b[r].width_num >= w[z].start.width_num && b[r].width_num <= w[z].end.width_num) &&
                (b[r].lenth_num >= w[z].start.lenth_num && b[r].lenth_num <= w[z].end.lenth_num)) ||
                ((b[r].lenth_num == 20 && b[r].width_num >5) || (b[r].width_num == 6 && b[r].lenth_num > 19))) {
                b[r].state = 'w';
            }
        }
        //set block of flag------------------------------------------------------------------------------------------------- 
        if ((b[r].floor == f.flag.floor) && 
            (b[r].width_num == f.flag.width_num) && 
            (b[r].lenth_num == f.flag.lenth_num)) {
            b[r].state = 'f';
        }
        

        //set bawana blocks-------------------------------------------------------------------------------------------------
       if ((b[r].floor == 0) && (b[r].width_num >6) && (b[r].lenth_num>20)){
            b[r].state = 'b';
        }
    }

  


    

    // ======== Move Player ========
    player ply[3];
    ply[0].die_index = 0;  // To manage Disoriented and Happy
    ply[1].die_index = 0;  // To manage Disoriented and Happy
    ply[2].die_index = 0;  // To manage Disoriented and Happy
    ply[0].movepoint = 100;
    ply[1].movepoint = 100;
    ply[2].movepoint = 100;
    ply[0].food_poison_rounds = 0;  // To manage food poison rounds
    ply[1].food_poison_rounds = 0;  // To manage food poison rounds
    ply[2].food_poison_rounds = 0;  // To manage food poison rounds

    //player A
    ply[0].name = 'A';
    ply[0].start.floor = 0; 
    ply[0].start.width_num = 6; 
    ply[0].start.lenth_num = 12; 
    ply[0].direction = 'N';
    ply[0].current = ply[0].start; 

    //player B
    ply[1].name = 'B';
    ply[1].start.floor = 0; 
    ply[1].start.width_num = 9; 
    ply[1].start.lenth_num = 8; 
    ply[1].direction = 'W';
    ply[1].current = ply[1].start;

    //player C
    ply[2].name = 'C';
    ply[2].start.floor = 0; 
    ply[2].start.width_num = 9; 
    ply[2].start.lenth_num = 16; 
    ply[2].direction = 'E';
    ply[2].current = ply[2].start; 
    
    //definr variables in this function
    int index[3]={0}, round=0, counter=0, disorient_count = 0,die_num = 0;
    int sd_value = seed();
    srand(sd_value);
    

    while(!f.win_value ){

        round++;
        counter++; //To manage stair direction.
        if(counter >= 5){
            // Change direction for all stairs
            for(int x = 0; x < number_of_stair; x++) {
                s[x].direction = rand() % 2;
            }
            counter = 0;
            printf("stair direction changed\n");
        }

        printf("\n");
        printf("===================================Round %d=======================================\n",round);
        printf("\n");
        for(int i=0;i<3;i++){
            printf("------------------------------------------player %c-----------------------------------------\n",ply[i].name);


            // Check if player is in food poison.
            if (ply[i].food_poison_rounds > 0) {
                printf("Player %c is still food poisoned and misses the turn for %d more rounds\n", 
                       ply[i].name, ply[i].food_poison_rounds);
                
                ply[i].food_poison_rounds--;
                
                // After 3 rounds, move player to random bawana block
                if (ply[i].food_poison_rounds == 0) {
                    int bc = rand()%12;
                    ply[i].current = bawan[bc].bwan;
                    printf("Player %c is now fit to proceed from the food poisoning episode and now placed on a [0, %d, %d] and the effects take place. \n", ply[i].name,bawan[bc].bwan.width_num,bawan[bc].bwan.lenth_num);
                    bawana_function(b,&ply[i]);
                }
                
                continue;  
            }

            
            if(ply[i].movepoint>250){ply[i].movepoint=250;}

            if(ply[i].current.floor == 0 && ply[i].current.width_num >6 && ply[i].current.lenth_num> 20){
                bawana_function(b,&ply[i]);
                continue;
            }

            else if(ply[i].movepoint <= 0){  // Enter the bawana when movepoints are zero.
                ply[i].current.floor = 0;
                ply[i].current.width_num = (rand()%3)+7;
                ply[i].current.lenth_num = (rand()%4)+21;
                printf("----------------------\n");
                printf("Movepoints are zero\n");
                printf("Position in Bawana = [0, %d, %d]\n",ply[i].current.width_num,ply[i].current.lenth_num);
                printf("----------------------\n");
                bawana_function(b,&ply[i]);} 

            if (ply[i].die_index == 5){       //Manage triggered situation.
                die_num = ((rand()%6)+1)*2;
                printf("Player %c is triggered and rolls and %d on the movement dice and move in the %d and moves <2 x value> cells.\n",ply[i].name,die_num,ply[i].direction);   //has a error. had put %d for ply[i].direction and had not put dir_value foe <2* value>
            } 
            else{die_num = (rand()%6)+1;}

            printf("counter value = %d\n",counter);

            if((ply[i].current.floor == ply[i].start.floor)&&
                (ply[i].current.width_num == ply[i].start.width_num) &&
                (ply[i].current.lenth_num == ply[i].start.lenth_num)){
                if(die_num==6){
                    index[i]=1;
                    if(i==0){ply[i].current.width_num=5; ply[i].current.lenth_num=12;}
                    else if(i==1){ply[i].current.width_num=9; ply[i].current.lenth_num=7;}
                    else if(i==2){ply[i].current.width_num=9; ply[i].current.lenth_num=17;}
                    printf("Player %c is at the starting area and rolls 6 on the movement dice and is placed on Floor:%d, Width:%d, Length:%d on the maze.\n", ply[i].name, ply[i].current.floor, ply[i].current.width_num, ply[i].current.lenth_num);
                }else{
                    printf("Player %c is at the starting area and rolls %d on the movement dice cannot enter the maze.\n", ply[i].name,die_num);
                    continue;
                }
            }
            
            else if (ply[i].die_index == 4){ // Handle move after disoriented
                        disorient_count++;

                        die_num = (rand()%6)+1;
    
                        ply[i].previous_direction=ply[i].direction;
                        int die_dir=(rand()%6)+1;
                        if(die_dir==2){ ply[i].direction='N';}
                        else if(die_dir==3){ ply[i].direction='E';}
                        else if(die_dir==4){ ply[i].direction='S';}
                        else if(die_dir==5){ ply[i].direction='W';}
                        else {ply[i].direction=ply[i].previous_direction;}
                        printf("Player %c rolls and %d on the movement dice and is disoriented and move in the %c and moves %d cells .\n", ply[i].name,die_num, ply[i].direction,die_num);

                        movePlayer(&ply[i],b,bawan,die_num,&f,s,number_of_stair);
                      
                        if(f.win_value) break;

                        
                        if (i == 0){
                            if((ply[i].current.floor == ply[1].current.floor) &&
                                (ply[i].current.width_num == ply[1].current.width_num) &&
                                (ply[i].current.lenth_num == ply[1].current.lenth_num)){ 
                                ply[1].current = ply[1].start;
                                printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[1].name,ply[1].name);
                                break;
                            }
                            else if((ply[i].current.floor == ply[2].current.floor) &&
                                    (ply[i].current.width_num == ply[2].current.width_num) &&
                                    (ply[i].current.lenth_num == ply[2].current.lenth_num)){ 
                                 ply[2].current = ply[2].start;
                                 printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[2].name,ply[2].name);
                                 break;
                            }
                        }
                        else if (i == 1){
                            if((ply[i].current.floor == ply[0].current.floor) &&
                                (ply[i].current.width_num == ply[0].current.width_num) &&
                                (ply[i].current.lenth_num == ply[0].current.lenth_num)){ 
                                 ply[0].current = ply[0].start;
                                 printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[0].name,ply[0].name);
                                 break;
                            } 
                            else if((ply[i].current.floor == ply[2].current.floor) &&
                                    (ply[i].current.width_num == ply[2].current.width_num) &&
                                    (ply[i].current.lenth_num == ply[2].current.lenth_num)){
                                ply[2].current = ply[2].start;
                                printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[2].name,ply[2].name);
                                break;
                            }
                        }
                        else{
                            if((ply[i].current.floor == ply[0].current.floor) &&
                                (ply[i].current.width_num == ply[0].current.width_num) &&
                                (ply[i].current.lenth_num == ply[0].current.lenth_num)){ 
                                ply[0].current = ply[0].start;
                                 printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[0].name,ply[0].name);
                                 break;
                            }
                            else if((ply[i].current.floor == ply[1].current.floor) &&
                                    (ply[i].current.width_num == ply[1].current.width_num) &&
                                    (ply[i].current.lenth_num == ply[1].current.lenth_num)){
                                ply[1].current = ply[1].start;
                                printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[1].name,ply[1].name);
                                break;
                            }
                        }
                        if(disorient_count == 4){
                            ply[i].die_index = 0;
                            printf("Player %c has recovered from disorientation.\n",ply->name);
                    
                        }
                        
            }
                
                       
            else if(index[i]>=4){
                    ply[i].previous_direction=ply[i].direction; 
                    index[i]=0;
                    int die_dir=(rand()%6)+1;
                    if(die_dir==2){ ply[i].direction='N';} //North
                    else if(die_dir==3){ ply[i].direction='E';} //East
                    else if(die_dir==4){ ply[i].direction='S';} //South
                    else if(die_dir==5){ ply[i].direction='W';} //West
                    else {ply[i].direction=ply[i].previous_direction;} //Empty
                    printf("Player %c rolls %c on the direction dice, changes direction to %c \n",
                         ply[i].name, ply[i].direction, ply[i].direction);

                    movePlayer(&ply[i],b,bawan,die_num,&f,s,number_of_stair);
                    if(f.win_value) break;

                    index[i]++;
                    if (i == 0){
                        if((ply[i].current.floor == ply[1].current.floor) &&
                           (ply[i].current.width_num == ply[1].current.width_num) &&
                           (ply[i].current.lenth_num == ply[1].current.lenth_num)){ 
                            ply[1].current = ply[1].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[1].name,ply[1].name);
                            break;
                        }
                        else if((ply[i].current.floor == ply[2].current.floor) &&
                                (ply[i].current.width_num == ply[2].current.width_num) &&
                                (ply[i].current.lenth_num == ply[2].current.lenth_num)){ 
                            ply[2].current = ply[2].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[2].name,ply[2].name);
                            break;
                        }
                    }
                    else if (i == 1){
                        if((ply[i].current.floor == ply[0].current.floor) &&
                           (ply[i].current.width_num == ply[0].current.width_num) &&
                           (ply[i].current.lenth_num == ply[0].current.lenth_num)){ 
                            ply[0].current = ply[0].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[0].name,ply[0].name);
                            break;
                        }
                        else if((ply[i].current.floor == ply[2].current.floor) &&
                                (ply[i].current.width_num == ply[2].current.width_num) &&
                                (ply[i].current.lenth_num == ply[2].current.lenth_num)){
                            ply[2].current = ply[2].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[2].name,ply[2].name);
                            break;
                        }
                    }
                    else{
                        if((ply[i].current.floor == ply[0].current.floor) &&
                           (ply[i].current.width_num == ply[0].current.width_num) &&
                           (ply[i].current.lenth_num == ply[0].current.lenth_num)){ 
                            ply[0].current = ply[0].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[0].name,ply[0].name);
                            break;
                        }
                        else if((ply[i].current.floor == ply[1].current.floor) &&
                               (ply[i].current.width_num == ply[1].current.width_num) &&
                               (ply[i].current.lenth_num == ply[1].current.lenth_num)){
                            ply[1].current = ply[1].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[1].name,ply[1].name);
                            break;
                        }
                    }
            }
            else{
                    movePlayer(&ply[i],b,bawan,die_num,&f,s,number_of_stair);
                    if(f.win_value) break;
                    

                    index[i]++;
                    if (i == 0){
                        if((ply[i].current.floor == ply[1].current.floor) &&
                           (ply[i].current.width_num == ply[1].current.width_num) &&
                           (ply[i].current.lenth_num == ply[1].current.lenth_num)){
                            ply[1].current = ply[1].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[1].name,ply[1].name);
                            break;
                        }
                        else if((ply[i].current.floor == ply[2].current.floor) &&
                                (ply[i].current.width_num == ply[2].current.width_num) &&
                                (ply[i].current.lenth_num == ply[2].current.lenth_num)){ 
                            ply[2].current = ply[2].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[2].name,ply[2].name);
                            break;
                        }
                    }
                    else if (i == 1){
                        if((ply[i].current.floor == ply[0].current.floor) &&
                           (ply[i].current.width_num == ply[0].current.width_num) &&
                           (ply[i].current.lenth_num == ply[0].current.lenth_num)){  
                            ply[0].current = ply[0].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[0].name,ply[0].name);
                            break;
                        }
                        else if((ply[i].current.floor == ply[2].current.floor) &&
                                (ply[i].current.width_num == ply[2].current.width_num) &&
                                (ply[i].current.lenth_num == ply[2].current.lenth_num)){
                            ply[2].current = ply[2].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[2].name,ply[2].name);
                            break;
                        }
                    }
                    else{
                        if((ply[i].current.floor == ply[0].current.floor) &&
                           (ply[i].current.width_num == ply[0].current.width_num) &&
                           (ply[i].current.lenth_num == ply[0].current.lenth_num)){  
                            ply[0].current = ply[0].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[0].name,ply[0].name);
                            break;
                        }
                        else if((ply[i].current.floor == ply[1].current.floor) &&
                               (ply[i].current.width_num == ply[1].current.width_num) &&
                               (ply[i].current.lenth_num == ply[1].current.lenth_num)){
                            ply[1].current = ply[1].start;
                            printf("player %c land on player %c, So player %c teleport to start position.\n",ply[i].name,ply[1].name,ply[1].name);
                            break;
                        }
                    }
                }
            
        }
        
    }
}
