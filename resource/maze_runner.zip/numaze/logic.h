#ifndef LOGIC_H
#define LOGIC_H

void IntMaze(void);
void ConfigFiles_and_RunPlayer(void);

#endif