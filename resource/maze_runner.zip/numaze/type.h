#ifndef TYPE_H
#define TYPE_H

typedef struct block {
    int floor;
    int width_num;
    int lenth_num;
    char state;
    int consumable; 
    int bonus_type;  
    int bonus_value; 
} block;

typedef struct stairtype{
    int direction;
    int s_value;
    block start;
    block end;
}stair;

typedef struct poletype{
    block start;
    block  end;
}pole;

typedef struct walltype{
    block start;
    block end;
}wall;

typedef struct flagtype{
    block flag ;
    int win_value;
    
}win;


typedef struct player{
    char name;
    block start;
    block current;
    block previous;
    char direction;
    char previous_direction;
    int movepoint;
    int die_index;  
    int food_poison_rounds;  
}player;



typedef struct bawanatype{
    char name;
    int bawana_value;
    block bwan;
}bawana;



extern block b[750];
extern player ply[3];
extern stair s[50];
extern pole p[50];
extern wall w[50];
extern win f;
extern bawana bawan[12];




#endif